library(sf)
fc = st_read("data/foreclosures_chi.gpkg")

library(tmap)
tm_shape(fc) + tm_graticules() + tm_polygons()

fcp = st_transform(fc, 2163)

tm_shape(fc) + tm_grid() + tm_polygons()

tm_shape(fcp) + tm_grid() + tm_polygons()

head(fcp)

tm_shape(fc) +
  tm_grid() + 
  tm_polygons("violent")

tm_shape(fcp) + 
  tm_grid() +
  tm_polygons("est_fcs_rt")

fcp_ols = lm(violent ~ est_fcs_rt + bls_unemp, data = fcp)
fcp_ols

summary(fcp_ols)

fcp$res_ols = resid(fcp_ols)
tm_shape(fcp) + tm_polygons("res_ols", breaks = c(-1250, 0, 1250), style = "cont")

library(spdep)
fcp_nb_q = poly2nb(fcp, queen = TRUE)
fcp_lw = nb2listw(fcp_nb_q, style = "W", zero.policy = TRUE)
fcp_lw

fcp_cen = st_centroid(st_geometry(fcp), of_largest_polygon = TRUE)
plot(st_geometry(fcp), border = "grey", lwd = 0.5)
plot(fcp_nb_q, coords = st_coordinates(fcp_cen), add = TRUE, lwd = 0.5)



library(spatialreg)
fcp_lag = lagsarlm(violent ~ est_fcs_rt + bls_unemp, data = fcp, listw = fcp_lw)
summary(fcp_lag)

fcp$res_lag = resid(fcp_lag)
tm_shape(fcp) + tm_polygons("res_lag", breaks = c(-1250, 0, 1250), style = "cont")

fcp_err = errorsarlm(violent ~ est_fcs_rt + bls_unemp, data = fcp, listw = fcp_lw)
summary(fcp_err)

fcp$res_err = resid(fcp_err)
tm_shape(fcp) + tm_polygons("res_err", breaks = c(-1250, 0, 1250), style = "cont")







library(sf)
library(spdep)
nc = st_read(system.file("shapes/sids.shp", package = "spData"), quiet = TRUE)
st_crs(nc) = "+proj=longlat +datum=NAD27"
row.names(nc) = as.character(nc$FIPSNO)
nc$prop74 = sqrt(nc$SID74 / nc$BIR74)
nc$nw74 = sqrt(nc$NWBIR74 / nc$BIR74)

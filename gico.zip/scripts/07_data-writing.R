library(sf)
library(spData)
nz_height

## st_write(obj = nz_height, dsn = "nz_height.gpkg")

## st_write(obj = nz_height, dsn = "nz_height.gpkg")

## st_write(obj = nz_height, dsn = "nz_height.csv", layer_options = "GEOMETRY=AS_XY")

## nz_height_coords = as.data.frame(st_coordinates(nz_height))
## nz_height2 = dplyr::bind_cols(nz_height, nz_height_coords) %>%
##   st_drop_geometry()
## write.csv(nz_height2, "nz_height.csv")

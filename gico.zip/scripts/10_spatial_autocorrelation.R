library(sf)
library(spdep)
nc = st_read(system.file("shapes/sids.shp", package = "spData"), quiet = TRUE)
st_crs(nc) = "+proj=longlat +datum=NAD27"
row.names(nc) = as.character(nc$FIPSNO)
nc$prop74 = nc$SID74 / nc$BIR74

library(tmap)
tm_shape(nc) + tm_polygons("prop74")

nc_nb_q = poly2nb(nc, queen = TRUE)
nc_lw = nb2listw(nc_nb_q, style = "B")
nc_lw

moran.test(nc$prop74, listw = nc_lw)

moran.mc(nc$prop74, listw = nc_lw, nsim = 100)

geary.test(nc$prop74, listw = nc_lw)

geary.mc(nc$prop74, listw = nc_lw, nsim = 100)

nc_locg = localG(nc$prop74, listw = nc_lw)
head(nc_locg)

nc$g = nc_locg

library(tmap)
tm_g1 = tm_shape(nc) + tm_polygons("prop74", style = "cont")
tm_g2 = tm_shape(nc) + tm_polygons("g", style = "cont")
tmap_arrange(tm_g1, tm_g2, ncol = 2)

moran.plot(nc$prop74, listw = nc_lw, labels = nc$NAME)



nc_locm = localmoran(nc$prop74, listw = nc_lw)
head(nc_locm)

nc$I = nc_locm[, 1]

library(tmap)
tm_m1 = tm_shape(nc) + tm_polygons("prop74", style = "cont")
tm_m2 = tm_shape(nc) + tm_polygons("I", style = "cont")
tmap_arrange(tm_m1, tm_m2, ncol = 2)

nc$I_pvalue = nc_locm[, 5]

library(tmap)
tm_m3 = tm_shape(nc) + tm_polygons("I_pvalue", style = "cont", breaks = c(0, 0.5, 1))
tmap_arrange(tm_m1, tm_m2, tm_m3, ncol = 3)

library(dplyr)
nc$prop74_scaled = as.vector(scale(nc$prop74))
nc$prop74_scaled_lag = lag.listw(nc_lw, nc$prop74_scaled)

nc = nc %>%
  mutate(mcluster_type = case_when(
    nc$prop74_scaled >= 0 & nc$prop74_scaled_lag >= 0 & nc_locm[, 5] <= 0.05 ~ "high-high",
    nc$prop74_scaled <= 0 & nc$prop74_scaled_lag <= 0 & nc_locm[, 5] <= 0.05 ~ "low-low",
    nc$prop74_scaled >= 0 & nc$prop74_scaled_lag <= 0 & nc_locm[, 5] <= 0.05 ~ "high-low",
    nc$prop74_scaled <= 0 & nc$prop74_scaled_lag >= 0 & nc_locm[, 5] <= 0.05 ~ "low-high",
    nc_locm[, 5] > 0.05 ~ "Not Significant"
  )) # classify the cluster types

tm_m4 = tm_shape(nc) + tm_polygons("mcluster_type")
tmap_arrange(tm_m1, tm_m4, ncol = 2)

data(pol_pres15, package = "spDataLarge")
?pol_pres15

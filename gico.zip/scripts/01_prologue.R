## install.packages("usethis")
## usethis::use_course("https://github.com/Nowosad/gico19/raw/master/gico.zip")

library(sf)
library(dplyr)
library(spdep)
library(tmap)
data(pol_pres15, package = "spDataLarge")

pres = pol_pres15 %>% 
  slice(1:5) %>% 
  mutate(id = 1:5)

tm_shape(pres) +
  tm_polygons("id", legend.show = FALSE) + 
  tm_text("id", size = 2)

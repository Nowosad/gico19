pres_nb_q = poly2nb(pres, queen = TRUE)
pres_nb_q

pres_lw = nb2listw(pres_nb_q, style = "B")
pres_lw

pres_mat = listw2mat(pres_lw)
pres_mat

## pres_cen = st_centroid(st_geometry(pres),
##                        of_largest_polygon = TRUE)
## 
## plot(st_geometry(pres), border = "grey", lwd = 0.5)
## plot(pres_nb_q, coords = st_coordinates(pres_cen),
##      add = TRUE, lwd = 0.5)



## pres_cen = st_centroid(st_geometry(pres),
##                        of_largest_polygon = TRUE)
## pres_nb_net = nb2lines(pres_nb_q,
##                 coords = st_coordinates(pres_cen))
## tm_shape(pres) + tm_polygons() +
##   tm_shape(pres_nb_net) + tm_lines()



pres_nb_q = poly2nb(pres, queen = TRUE)
pres_cen = st_centroid(st_geometry(pres),
                       of_largest_polygon = TRUE)
pres_dists = nbdists(pres_nb_q, pres_cen)
pres_dists

pres_dists_vec = unlist(pres_dists)
pres_dists_vec

hist(pres_dists_vec)

pres_nb_d = dnearneigh(pres_cen, d1 = 0, d2 = 15000)
pres_nb_d

pres_mat2 = nb2mat(pres_nb_d, zero.policy = TRUE)
pres_mat2







pres_lw1 = nb2listw(pres_nb_q, style = "B")
pres_mat1 = listw2mat(pres_lw1)
pres_mat1

pres_lw2 = nb2listw(pres_nb_q, style = "W")
pres_mat2 = listw2mat(pres_lw2)
pres_mat2

pres_lw3 = nb2listw(pres_nb_q, style = "C")
pres_mat3 = listw2mat(pres_lw3)
pres_mat3

pres_lw4 = nb2listw(pres_nb_q, style = "U")
pres_mat4 = listw2mat(pres_lw4)
pres_mat4

data(pol_pres15, package = "spDataLarge")
?pol_pres15

library(spData)

library(sf)
st_crs(world)
st_crs(world)$proj4string

london_geo = data.frame(lon = -0.1, lat = 51.5) %>% 
  st_as_sf(coords = c("lon", "lat"), crs = 4326)

# an EPSG code of 27700: the British National Grid
london_proj = st_transform(london_geo, crs = 27700)





london_geo_buff = st_buffer(london_geo, dist = 1)
london_proj_buff = st_buffer(london_proj, 111320)





library(sf)
zion = st_read(system.file("vector/zion.gpkg", package = "spDataLarge"), quiet = TRUE)
data(zion_points, package = "spDataLarge")





zion_points2a = st_transform(zion_points,
                             crs = 26912)

zion_points2b = st_transform(zion_points,
                             crs = "+proj=utm +zone=12 +ellps=GRS80 +towgs84=0,0,0,0,0,0,0 +units=m +no_defs")

zion_points3 = st_transform(zion_points, st_crs(zion))
zion_points3





zion = st_read(system.file("vector/zion.gpkg", package = "spDataLarge"), quiet = TRUE)



zion_center = zion %>% 
  st_centroid() %>% 
  st_transform(4326) %>% 
  st_coordinates()

new_crs = paste0("+proj=laea", 
                " +lat_0=", zion_center[, 2],
                " +lon_0=", zion_center[, 1])
new_crs

zion2 = st_transform(zion, new_crs)



vector_filepath = system.file("vector/zion.gpkg", package = "spDataLarge")
new_vector = st_read(vector_filepath)
st_crs(new_vector) # get CRS
new_vector = st_set_crs(new_vector, 4326) # set CRS

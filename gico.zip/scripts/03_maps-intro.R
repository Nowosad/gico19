library(sf)
library(tmap)
library(spData)

tm_shape(nz) + 
  tm_fill()

tm_shape(nz) + 
  tm_borders()

tm_shape(nz) +
  tm_fill() +
  tm_borders() 

tm_shape(nz) +
  tm_polygons()

tm_shape(nz) +
  tm_fill(col = "blue") +
  tm_borders()

tm_shape(nz) +
  tm_fill(col = "#00247D") +
  tm_borders()

nz

tm_shape(nz) + 
  tm_polygons(col = "Median_income")

tm_shape(nz) + 
  tm_polygons(col = "Median_income",
              title = "Median Income (NZD):")

tm_shape(nz) +
  tm_polygons(col = "Median_income", 
              breaks = c(20000, 25000, 30000, 35000),
              labels = c("low", "medium", "high"))

tm_shape(nz) + 
  tm_polygons(col = "Median_income",
              style = "cont")

world_moll = st_transform(world, crs = "+proj=moll")
tm_shape(world_moll) +
  tm_polygons(col = "pop")

tm_shape(world_moll) +
  tm_polygons(col = "pop", 
              style = "log10_pretty")

tm1 = tm_shape(world_moll) +
  tm_polygons(col = "pop")

tm2 = tm_shape(world_moll) +
  tm_polygons(col = "pop", 
              style = "log10_pretty")

tmap_arrange(tm1, tm2, nrow = 1)

nz

tm_shape(nz) +
  tm_polygons(col = "Name")

## tmaptools::palette_explorer()

tm_shape(nz) +
  tm_polygons(col = "Island")

tm_shape(nz) +
  tm_polygons(col = "Island",
              palette = "Set2")

tm_shape(nz) +
  tm_polygons(col = "Island",
              palette = "-Set2")

library(sf)
library(tmap)
library(dplyr)
library(spData)
library(spDataLarge)

urb_2020 =  subset(urban_agglomerations, year == 2020)

tm_shape(world) +
  tm_polygons(col = "#e6e6e6") +
  tm_shape(urb_2020) +
  tm_symbols(col = "#c15b5b")

tm_shape(nz) + 
  tm_graticules() +
  tm_polygons()

tm_shape(nz) +
  tm_polygons() +
  tm_scale_bar(breaks = c(0, 100, 200), text.size = 1) +
  tm_compass(position = c("LEFT", "top"), type = "rose", size = 2) +
  tm_logo("https://www.r-project.org/logo/Rlogo.png", height = 2) +
  tm_credits("J. Nowosad, 2019")

tm_shape(nz) +
  tm_polygons() +
  tm_layout(title = "New Zealand")

tm_shape(nz) +
  tm_polygons() +
  tm_layout(main.title = "New Zealand")

tm_shape(nz) +
  tm_polygons() +
  tm_layout(main.title = "New Zealand",
            bg.color = "lightblue")

tm_shape(nz) +
  tm_polygons(col = "Median_income") +
  tm_layout(inner.margins = c(0.1, 0.1, 0.1, 0.3))

tm_shape(nz) +
  tm_polygons(col = "Median_income") +
  tm_layout(legend.position = c("LEFT", "TOP"))

tm_shape(nz) +
  tm_polygons(col = "Median_income") +
  tm_layout(legend.outside = TRUE)

tm_shape(nz) +
  tm_polygons(col = "Median_income") +
  tm_layout(legend.show = FALSE)

tm1 = tm_shape(nz) +
  tm_polygons()
tm1

tmap_save(tm1,
          filename = "my_map.png",
          width = 4,
          height = 6,
          asp = 0)

tmap_save(tm1, 
          filename = "my_map.html")



library(sf)
library(tmap)
library(spData)
library(dplyr)
us_states = left_join(us_states, us_states_df, by = c("NAME" = "state"))

library(spData)
library(sp)
library(sf)
world_sp = as(world, Class = "Spatial")
# sp functions ...

world_sf = st_as_sf(world_sp)

# lsf.str("package:sf")
ls("package:sf")



library(spData)
library(sf)

world

plot(world)

file_path = system.file("shapes/world.gpkg", package = "spData")
file_path
# world = st_read(file_path)
world = st_read("/home/jn/R/x86_64-redhat-linux-gnu-library/3.6/spData/shapes/world.gpkg")

cycle_hire_txt = system.file("misc/cycle_hire_xy.csv", package = "spData")
cycle_hire_xy = st_read(cycle_hire_txt, options = c("X_POSSIBLE_NAMES=X",
                                                    "Y_POSSIBLE_NAMES=Y"))

my_point_sfg1 = st_point(c(1, 5))
my_point_sfg2 = st_point(c(3, 3))
my_point_sfc = st_sfc(my_point_sfg1, my_point_sfg2, crs = 4326)
my_df = data.frame(name = c("first", "second"))
my_point_sf = st_sf(my_df, geometry = my_point_sfc)

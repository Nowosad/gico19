library(sf)
library(dplyr)
library(spData)



## nz
## nz_height

nz_height2 = st_join(nz_height, nz)
dim(nz_height)
dim(nz_height2)

nz2 = st_join(nz, nz_height)
dim(nz)
dim(nz2)

library(sf)
library(dplyr)
library(spData)
world_sum = world %>% 
  summarize(pop = sum(pop, na.rm = TRUE), n = n())

world_agg = world %>%
  group_by(continent) %>%
  summarize(pop = sum(pop, na.rm = TRUE))



library(sf)
library(dplyr)
library(spData)
library(units)

seine$length = st_length(seine)
seine$length = set_units(st_length(seine), "km")
seine$length = as.numeric(st_length(seine))

st_length(nz)
nz2 = nz %>% st_cast("MULTILINESTRING")
st_length(nz2)
nz$perimeter = st_length(nz2)

nz$area = st_area(nz)
nz$area = set_units(st_area(nz), "km2")
nz$area = as.numeric(st_area(nz))

library(rmapshaper)
us_states2163 = st_transform(us_states, 2163)
us_states2163$AREA = as.numeric(us_states2163$AREA)
us_states_simp = ms_simplify(us_states2163, keep = 0.01, keep_shapes = TRUE)



nz_cen = st_centroid(nz)
nz_pos = st_point_on_surface(nz)
